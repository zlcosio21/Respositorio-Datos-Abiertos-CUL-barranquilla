from autenticacion.models import Usuario, Rol
import django_filters


class UsuarioFilter(django_filters.FilterSet):
    rol = django_filters.CharFilter(field_name="rol__nombre", lookup_expr="icontains")


class HistorialFilter(django_filters.FilterSet):
    historial_id = django_filters.NumberFilter(field_name="id", lookup_expr='exact', label="Id del Historial")
