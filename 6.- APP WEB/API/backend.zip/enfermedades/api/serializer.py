from autenticacion.models import Usuario
from rest_framework import serializers
from salud.models import Historial


class PrediccionSerializer(serializers.Serializer):
    enfermedad = serializers.CharField()
    sexo = serializers.IntegerField()
    artritis = serializers.IntegerField()
    epoc = serializers.IntegerField()
    asma = serializers.IntegerField()
    insuficiencia_cardiaca = serializers.IntegerField()
    cancer = serializers.IntegerField()
    herfanas_emofilias_y_otras_coag = serializers.IntegerField()
    cirugia_cardiaca = serializers.IntegerField()
    trasplantados = serializers.IntegerField()
    insuficiencia_renal_cronica = serializers.IntegerField()
    tipo_erc = serializers.IntegerField()
    eapb = serializers.IntegerField()
    diabetes = serializers.IntegerField()


class HistorialSerializer(serializers.ModelSerializer):
    paciente = serializers.PrimaryKeyRelatedField(queryset=Usuario.objects.all())
    medico = serializers.PrimaryKeyRelatedField(queryset=Usuario.objects.all())

    class Meta:
        model = Historial
        fields = "__all__"
