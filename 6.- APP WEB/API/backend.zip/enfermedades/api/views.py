from django_filters.rest_framework import DjangoFilterBackend
from autenticacion.serializer import UsuarioSerializer
from utils.predecir import procesar_datos_y_predecir
from api.serializer import PrediccionSerializer
from rest_framework.decorators import api_view
from api.serializer import HistorialSerializer
from rest_framework.response import Response
from autenticacion.models import Usuario
from api.filters import HistorialFilter
from api.filters import UsuarioFilter
from rest_framework import viewsets
from salud.models import Historial
from rest_framework import status


@api_view(["POST"])
def prediccion(request):
    serializer = PrediccionSerializer(data=request.data)

    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_200_OK)

    enfermedad = serializer.validated_data["enfermedad"]

    if enfermedad != "Hipertensión" and enfermedad != "Diabetes":
        return Response({"error": "La enfermedad debe ser Hipertensión o Diabetes"}, status=status.HTTP_400_BAD_REQUEST)

    sexo = serializer.validated_data["sexo"]
    artritis = serializer.validated_data["artritis"]
    epoc = serializer.validated_data["epoc"]
    asma = serializer.validated_data["asma"]
    insuficiencia_cardiaca = serializer.validated_data["insuficiencia_cardiaca"]
    cancer = serializer.validated_data["cancer"]
    herfanas_emofilias_y_otras_coag = serializer.validated_data["herfanas_emofilias_y_otras_coag"]
    cirugia_cardiaca = serializer.validated_data["cirugia_cardiaca"]
    trasplantados = serializer.validated_data["trasplantados"]
    insuficiencia_renal_cronica = serializer.validated_data["insuficiencia_renal_cronica"]
    tipo_erc = serializer.validated_data["tipo_erc"]
    eapb = serializer.validated_data["eapb"]
    diabetes = serializer.validated_data["diabetes"]

    sample_data = {
        "Sexo": [sexo],
        "Artritis": [artritis],
        "EPOC": [epoc],
        "Asma": [asma],
        "Insuficiencia cardiaca": [insuficiencia_cardiaca],
        "Cáncer": [cancer],
        "Huerfanas- Hemofilias y otras Coag": [herfanas_emofilias_y_otras_coag],
        "Cirugia Cardiaca": [cirugia_cardiaca],
        "Trasplantados": [trasplantados],
        "Insuficiencia renal cronica": [insuficiencia_renal_cronica],
        "TIPO ERC": [tipo_erc],
        "EAPB": [eapb],
        "Diabetes": [diabetes]
    }

    resultado = procesar_datos_y_predecir(enfermedad, sample_data)

    return Response({"message": resultado}, status=status.HTTP_200_OK)


class UsuarioViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Usuario.objects.all()
    serializer_class = UsuarioSerializer
    filter_backends = (DjangoFilterBackend,)
    filterset_class = UsuarioFilter


class HistorialViewSet(viewsets.ModelViewSet):
    queryset = Historial.objects.all()
    serializer_class = HistorialSerializer
    filter_backends = (DjangoFilterBackend,)
    filterset_class = HistorialFilter