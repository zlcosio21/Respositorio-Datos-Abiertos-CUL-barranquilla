from autenticacion.models import Rol, Usuario
from django.contrib import admin


class RolAdmin(admin.ModelAdmin):
    readonly_fields = ("created_at", "updated_at")


admin.site.register(Rol, RolAdmin)
admin.site.register(Usuario)
