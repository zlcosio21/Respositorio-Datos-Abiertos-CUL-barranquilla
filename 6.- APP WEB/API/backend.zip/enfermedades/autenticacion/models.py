from django.contrib.auth.models import AbstractUser
from enfermedades.base_models import Models
from django.db import models


# Create your models here.
class Rol(Models):
    nombre = models.CharField(max_length=80, null=False, unique=True)


class Usuario(AbstractUser):
    nombre = models.CharField(max_length=80, null=False)
    apellido = models.CharField(max_length=80, null=False)
    tipo_documento = models.CharField(max_length=50, null=False)
    numero_documento = models.CharField(max_length=20, null=False)
    edad = models.PositiveSmallIntegerField(null=False)
    direccion = models.CharField(max_length=100, null=False)
    numero_telefono = models.CharField(max_length=15, null=False)
    sexo = models.CharField(max_length=80, null=False)
    rol = models.ForeignKey(Rol, on_delete=models.CASCADE, null=True)

    @classmethod
    def nombre_de_usuario_existe(cls, nombre_usuario):
        return cls.objects.filter(username=nombre_usuario).exists()

    @classmethod
    def correo_en_uso(cls, correo):
        return cls.objects.filter(email=correo).exists()

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['tipo_documento', 'numero_documento'], name='unique_documento')
        ]
