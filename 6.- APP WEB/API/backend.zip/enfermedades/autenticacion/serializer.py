from autenticacion.models import Usuario, Rol
from rest_framework import serializers


class RolSerializer(serializers.ModelSerializer):
    class Meta:
        model = Rol
        fields = ["nombre"]


class UsuarioSerializer(serializers.ModelSerializer):
    rol = RolSerializer(read_only=True)
    usuario = serializers.CharField(source="username")
    correo = serializers.EmailField(source="email")
    contrasena = serializers.CharField(source="password")

    class Meta:
        model = Usuario
        fields = [
            "id",
            "usuario",
            "sexo",
            "edad",
            "correo",
            "contrasena",
            "tipo_documento",
            "numero_documento",
            "numero_telefono",
            "direccion",
            "nombre",
            "apellido",
            "rol"
        ]
