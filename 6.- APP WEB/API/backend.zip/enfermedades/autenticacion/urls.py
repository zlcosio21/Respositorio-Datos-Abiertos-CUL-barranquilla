from autenticacion import views
from django.urls import path


urlpatterns = [
    path("registro", views.registro),
    path("registro_medico", views.registro_medico),
    path("login", views.login),
    path("logout", views.logout),
]
