from rest_framework.decorators import api_view, permission_classes, authentication_classes
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from autenticacion.serializer import UsuarioSerializer
from rest_framework.authtoken.models import Token
from autenticacion.models import Usuario, Rol
from rest_framework.response import Response
from rest_framework import status


# Create your views here.
@api_view(["POST"])
def registro(request):
    serializer = UsuarioSerializer(data=request.data)

    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_200_OK)

    username = serializer.validated_data["username"]
    email = serializer.validated_data["email"]
    password = serializer.validated_data["password"]
    tipo_documento = serializer.validated_data["tipo_documento"]
    numero_documento = serializer.validated_data["numero_documento"]

    if Usuario.nombre_de_usuario_existe(username):
        return Response({"error": "El nombre de usuario ya existe"}, status=status.HTTP_400_BAD_REQUEST)

    if Usuario.correo_en_uso(email):
        return Response({"error": "El correo ya existe"}, status=status.HTTP_400_BAD_REQUEST)

    if len(password) < 8:
        return Response({"error": "La contraseña debe tener minimo 8 caracteres"}, status=status.HTTP_400_BAD_REQUEST)


    rol, _ = Rol.objects.get_or_create(nombre="Paciente")

    usuario = serializer.save()

    nombre = serializer.validated_data["nombre"]
    apellido = serializer.validated_data["apellido"]
    numero_telefono = serializer.validated_data["numero_telefono"]
    direccion = serializer.validated_data["direccion"]

    usuario.username = username
    usuario.nombre = nombre
    usuario.apellido = apellido
    usuario.tipo_documento = tipo_documento
    usuario.numero_documento = numero_documento
    usuario.numero_telefono = numero_telefono
    usuario.direccion = direccion
    usuario.rol = rol
    usuario.set_password(password)
    usuario.email = email
    usuario.save()

    token = Token.objects.create(user=usuario)

    user_data = serializer.data
    user_data["rol"] = usuario.rol.nombre

    return Response({"token": token.key, "user": user_data}, status=status.HTTP_201_CREATED)


@api_view(["POST"])
def registro_medico(request):
    serializer = UsuarioSerializer(data=request.data)

    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_200_OK)

    username = serializer.validated_data["username"]
    email = serializer.validated_data["email"]
    password = serializer.validated_data["password"]
    tipo_documento = serializer.validated_data["tipo_documento"]
    numero_documento = serializer.validated_data["numero_documento"]

    if Usuario.nombre_de_usuario_existe(username):
        return Response({"error": "El nombre de usuario ya existe"}, status=status.HTTP_400_BAD_REQUEST)

    if Usuario.correo_en_uso(email):
        return Response({"error": "El correo ya existe"}, status=status.HTTP_400_BAD_REQUEST)

    if len(password) < 8:
        return Response({"error": "La contraseña debe tener minimo 8 caracteres"}, status=status.HTTP_400_BAD_REQUEST)


    rol, _ = Rol.objects.get_or_create(nombre="Medico")

    usuario = serializer.save()

    nombre = serializer.validated_data["nombre"]
    apellido = serializer.validated_data["apellido"]
    numero_telefono = serializer.validated_data["numero_telefono"]
    direccion = serializer.validated_data["direccion"]

    usuario.username = username
    usuario.nombre = nombre
    usuario.apellido = apellido
    usuario.tipo_documento = tipo_documento
    usuario.numero_documento = numero_documento
    usuario.numero_telefono = numero_telefono
    usuario.direccion = direccion
    usuario.rol = rol
    usuario.set_password(password)
    usuario.email = email
    usuario.save()

    token = Token.objects.create(user=usuario)

    user_data = serializer.data
    user_data["rol"] = usuario.rol.nombre

    return Response({"token": token.key, "user": user_data}, status=status.HTTP_201_CREATED)


@api_view(["POST"])
def login(request):
    email = request.data.get("correo")
    password = request.data.get("contrasena")

    if not Usuario.objects.filter(email=email).exists():
        return Response({"error": "El correo no existe"}, status=status.HTTP_401_UNAUTHORIZED)

    usuario = Usuario.objects.get(email=email)

    if not usuario.check_password(password):
        return Response({"error": "La contraseña es incorrecta o no se ha ingresado"}, status=status.HTTP_401_UNAUTHORIZED)

    token, created = Token.objects.get_or_create(user=usuario)
    serializer = UsuarioSerializer(instance=usuario)

    user_data = serializer.data
    user_data["rol"] = usuario.rol.nombre if usuario.rol else "Sin rol asignado"

    return Response({"token": token.key, "user": user_data}, status=status.HTTP_201_CREATED)


@api_view(["DELETE"])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticated])
def logout(request):
    token = request.auth

    if not token:
        return Response({"error": "No se encontró el token de autenticación"}, status=status.HTTP_400_BAD_REQUEST)

    token.delete()

    return Response({"message": "Sesión cerrada exitosamente"}, status=status.HTTP_200_OK)
