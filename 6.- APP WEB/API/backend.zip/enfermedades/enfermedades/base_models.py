from django.db import models


# Abstract class
class Models(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    SearchableFields = ["id"]

    class Meta:
        abstract = True