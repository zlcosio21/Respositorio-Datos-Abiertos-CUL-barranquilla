from salud.models import Historial, TipoCita, Agendamiento, Cita
from django.contrib import admin


class HistorialAdmin(admin.ModelAdmin):
    readonly_fields = ("created_at", "updated_at")


class TipoCitaAdmin(admin.ModelAdmin):
    readonly_fields = ("created_at", "updated_at")


class AgendamientoAdmin(admin.ModelAdmin):
    readonly_fields = ("created_at", "updated_at")


class CitaAdmin(admin.ModelAdmin):
    readonly_fields = ("created_at", "updated_at")


admin.site.register(Historial, HistorialAdmin)
admin.site.register(TipoCita, TipoCitaAdmin)
admin.site.register(Agendamiento, AgendamientoAdmin)
admin.site.register(Cita, CitaAdmin)