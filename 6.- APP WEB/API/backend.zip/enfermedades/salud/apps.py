from salud.csv_loader import load_csv_data
from django.apps import AppConfig


class SaludConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'salud'

    def ready(self):
        load_csv_data()