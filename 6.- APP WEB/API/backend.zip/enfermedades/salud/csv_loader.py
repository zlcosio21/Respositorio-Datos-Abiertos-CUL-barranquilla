import pandas as pd
import os

loaded_data = None

def load_csv_data():
    global loaded_data

    if loaded_data is None:
        file_path = "salud/enfermedades_bucaramanga.csv"

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"El archivo CSV no se encuentra en la ruta: {file_path}")

        loaded_data = pd.read_csv(file_path)

    return loaded_data
