from enfermedades.base_models import Models
from autenticacion.models import Usuario
from django.db import models


# Create your models here.
class Historial(Models):
    paciente = models.ForeignKey(Usuario, on_delete=models.CASCADE, null=False, related_name="historial_paciente")
    medico = models.ForeignKey(Usuario, on_delete=models.CASCADE, null=False, related_name="historial_medico")
    frecuencia_fuma = models.CharField(max_length=50, null=False)
    frecuencia_alcohol = models.CharField(max_length=50, null=False)
    enfermedad_cronica = models.BooleanField(null=False)
    antecedentes_enfermadades_cardiacas = models.BooleanField(null=False)
    antecedentes_diabetes = models.BooleanField(null=False)
    antecedentes_cancer = models.BooleanField(null=False)
    atecendetes_hipertension = models.BooleanField(null=False)
    cirugia = models.BooleanField(null=False)
    tipo_cirugia = models.CharField(max_length=80, null=True)
    discapacidad = models.BooleanField(null=False)
    problemas_auditivos = models.BooleanField(null=False)
    problemas_respiratorios = models.BooleanField(null=False)
    problemas_cardiacos = models.BooleanField(null=False)
    alergico = models.BooleanField(null=False)
    medicamento_alergico = models.CharField(max_length=200, null=True)


class TipoCita(Models):
    nombre = models.CharField(max_length=100, null=False, unique=True)


class Agendamiento(Models):
    fecha = models.DateField(null=False)
    tipo_cita = models.ForeignKey(TipoCita, on_delete=models.CASCADE, null=False)
    paciente = models.ForeignKey(Usuario, on_delete=models.CASCADE, null=False, related_name="agendamiento_paciente")
    medico = models.ForeignKey(Usuario, on_delete=models.CASCADE, null=False, related_name="agendamiento_medico")
    requiere_laboratorio = models.BooleanField(null=False)


class Cita(Models):
    agendamiento = models.ForeignKey(Agendamiento, on_delete=models.CASCADE, null=False)
    diagnostico_general = models.TextField(null=False, blank=False)
    diagnostico_hipertension = models.TextField(null=False, blank=False)
    diagnostico_diabetes = models.TextField(null=False, blank=False)
    resultado_prediccion_diabetes = models.CharField(max_length=200, null=False, blank=False)
    resultado_prediccion_hipertension = models.CharField(max_length=200, null=False, blank=False)
    medicamentos = models.CharField(max_length=200, null=False, blank=False)
    observacion = models.TextField(null=False, blank=False)
    presion_arterial_sistolica = models.DecimalField(max_digits=5, decimal_places=1)
    presion_arterial_diastolica = models.DecimalField(max_digits=5, decimal_places=1)
    frecuencia_cardiaca = models.PositiveSmallIntegerField()
    nivel_glucosa = models.DecimalField(max_digits=5, decimal_places=1)
    tipo_diabetes = models.CharField(max_length=80, null=True, blank=True)
    recomendaciones_hipertension = models.TextField(null=True, blank=True)
    recomendaciones_diabetes = models.TextField(null=True, blank=True)
