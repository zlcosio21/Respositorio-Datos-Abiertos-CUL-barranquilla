from autenticacion.models import Usuario, Rol


def crear_roles():
    administrador, _ = Rol.objects.get_or_create(nombre="Administrador")
    medico, _ = Rol.objects.get_or_create(nombre="Medico")
    paciente, _ = Rol.objects.get_or_create(nombre="Paciente")


def super_user(username, email, password, nombre, apellido, tipo_documento, numero_documento, edad, direccion, numero_telefono, sexo, rol=None):
    user = Usuario.objects.create_superuser(
        username=username,
        email=email,
        password=password,
        nombre=nombre,
        apellido=apellido,
        tipo_documento=tipo_documento,
        numero_documento=numero_documento,
        edad=edad,
        direccion=direccion,
        numero_telefono=numero_telefono,
        sexo=sexo,
        rol=rol
    )
    user.save()
    print(f"Superusuario '{username}' creado con éxito.")