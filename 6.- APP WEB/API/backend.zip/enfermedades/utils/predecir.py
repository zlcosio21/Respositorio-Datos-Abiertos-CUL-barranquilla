from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from salud.csv_loader import load_csv_data
from sklearn.metrics import accuracy_score
import pandas as pd


def procesar_datos_y_predecir(enfermedad, sample_data):
    data = load_csv_data()

    columns_to_keep = [
        "Sexo",
        "Artritis",
        "Hipertensión",
        "EPOC",
        "Asma",
        "Insuficiencia cardiaca",
        "Cáncer",
        "Huerfanas- Hemofilias y otras Coag",
        "Cirugia Cardiaca",
        "Trasplantados",
        "Insuficiencia renal cronica",
        "TIPO ERC",
        "EAPB",
        "Diabetes",
    ]

    data = data[columns_to_keep]
    data.dropna(inplace=True)

    label_encoders = {}

    for column in data.select_dtypes(include=["object"]).columns:
        le = LabelEncoder()
        data[column] = le.fit_transform(data[column])
        label_encoders[column] = le

    X = data.drop(columns=[enfermedad])
    y = data[enfermedad]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestClassifier(random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)

    sample_df = pd.DataFrame(sample_data)
    sample_prediction = model.predict(sample_df)

    resultados = {
        "Hipertensión": (
            "Los resultados sugieren que podría haber indicios de hipertensión. Se recomienda una revisión médica más detallada.",
            "No se observan indicios de hipertensión en esta evaluación, pero es recomendable seguir monitoreando tu salud regularmente."
        ),
        "Diabetes": (
            "Existen algunos indicios que sugieren que podrías estar en riesgo de diabetes. Es importante hablar con tu médico para un diagnóstico adecuado.",
            "No hay indicios de diabetes en esta evaluación. Aun así, sigue una vida saludable y consulta con tu médico para chequeos regulares."
        )
    }

    if sample_prediction[0] == 1 and enfermedad in resultados:
        resultado = resultados[enfermedad][0]
    else:
        resultado = resultados[enfermedad][1]

    return resultado
